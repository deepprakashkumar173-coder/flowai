# FlowAI 🚀

## Idea
FlowAI is an AI-powered platform that converts ideas into execution plans.

## Features
- Research generation
- Project planning
- Content creation
- Learning roadmap

## Tech Stack
Frontend: HTML / React
Backend: Node.js
AI: OpenAI

## How to Run

Frontend:
Open frontend/index.html

Backend:
node backend/server.js

## Future Scope
- Full AI integration
- User login system
- Database support

## Conclusion
FlowAI turns ideas into execution in minutes.
